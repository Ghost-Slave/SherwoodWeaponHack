# WCodeG/ACodeG

Generates Sherwood Dungeon codes (which copies to your clipboard ^^) for weapons, amulets, rings and avatar strings. I included images of all items.

# Installing

`npm install inquirer`

# Starting

```
node WCodeG.js
node ACodeG.js
```
